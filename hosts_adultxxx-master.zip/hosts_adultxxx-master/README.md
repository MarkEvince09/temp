# hosts_adultxxx
Blocks ads and redirects from specific adult websites
More porn sites to analyze are welcome so just shoot me a message and I'll work on getting it added.

So far the following porn sites are monitored. The goal here is to block ads and redirects while not breaking the video playback. Some sites may attempt to prompt you to turn off your adblocker or remove your VPN if you can't see a video. I do not recommend this and would just try a different site instead.

-  Adsterra Advertising Network
-  Biqle.com
-  Biqle.org
-  Biqle.ru
-  BuyMedia Advertising Network
-  ClickAdu / Propeller Ads
-  Daftporn.com
-  Daft.sex (formerly Daftsex.com)
-  Daftsex.net
-  Efukt.com
-  Eporner.com
-  Fxporn.net
-  GoodPorn.se
-  GoodPorn.to
-  Gotporn.com
-  Hclips.com
-  Heavy-r.com
-  Hilltop Ads
-  Hitprn.com
-  Internetchicks.com
-  JuicyAds
-  Livejasmin
-  Netfapx.com
-  Noodlemagazine.com
-  Onlyfullporn.video
-  Onlyporn.tube
-  Peekvids.com
-  Playvids.com
-  Porn.com
-  Pornhd8k.net
-  Pornhits.com
-  Pornhub.com
-  Pornoeggs.com
-  Pornone.com
-  Porntrex.com
-  Pornve.com
-  Pornwild.com
-  Pornwiss.com
-  Redtube.com (formerly Biqle.com)
-  Social Media / Miscellaneous / Unknowns / Experimentals
-  Spankbang.com
-  Stripchat / Stripcdn
-  Syndication / ExoClick / RealSrv / GoAdServer
-  Terk.nl
-  Vueey.com
-  Xhamster.com
-  Xnxx.com
-  Xtapes.to
-  Xvideos.com
-  Yesporn.vip
-  Yespornplease.sexy
-  Youfreeporntube.com
-  Youporn.com



In order to use this hosts file, you should first back up your existing one located at : <b>C:\Windows\System32\drivers\etc</b>

Now download the "hosts" file within this branch and paste it into: <b>C:\Windows\System32\drivers\etc</b>

Afterwards, you should flush your DNS settings by opening a command prompt window: <b>Windows key</b> + <b>r</b> ==> <b>cmd</b> ==> ENTER

Type the following into the command line window: <b>ipconfig /flushdns</b>

You should now be set for a safer browser experience.


I've also included some regular expressions to be used within 
<a href="https://docs.pi-hole.net/main/basic-install/">Pi-hole</a> if you'd like. I've been using them without an issue but I would love additional testers and feedback to make sure it's safe for others' setups as well.

Thanks for any help and suggestions about additional sites to clean up. If you'd like to donate via Paypal, click <a href="http://paypal.me/d1savow3d">here</a>. Thank you!
